package pe.dominiotech.movil.safe2biz.base.activity

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.appcompat.widget.Toolbar
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast

import com.androidnetworking.AndroidNetworking
import com.androidnetworking.common.Priority
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.JSONObjectRequestListener

import org.json.JSONException
import org.json.JSONObject

import java.util.ArrayList
import java.util.HashMap
import kotlinx.android.synthetic.main.simple_list.*

import pe.dominiotech.movil.safe2biz.MainApplication
import pe.dominiotech.movil.safe2biz.model.UnidadBean
import pe.dominiotech.movil.safe2biz.service.ListaVerificacionService
import pe.dominiotech.movil.safe2biz.service.UsuarioService
import pe.dominiotech.movil.safe2biz.R
import pe.dominiotech.movil.safe2biz.base.adapter.ListaUnidadesAdapter
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper


class ListaUnidadesActivity : AppCompatActivity() {

    private var app: MainApplication? = null
    private var cardViewAdapter: ListaUnidadesAdapter? = null
    internal var onStartCount = 0
    private var listaVerificacionService: ListaVerificacionService? = null
    private var usuarioService: UsuarioService? = null

    private val isOnline: Boolean
        get() {
            val cm = getSystemService(
                    Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            var result = false
            val capabilities = cm.getNetworkCapabilities(cm.activeNetwork)
            if (capabilities != null) {
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    result = true
                } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                    result = true
                }
            }
            return result
        }


    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    public override fun onCreate(savedInstanceState: Bundle?) {
        setupTheme()
        super.onCreate(savedInstanceState)

        /*        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {             @Override             public void uncaughtException(Thread paramThread, Throwable paramThrowable) {                 app.setUsuarioEnSesion(null);                 Intent intent = new Intent(getApplicationContext(), LoginActivity.class);                 intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);                 startActivity(intent);                 System.exit(2);             }         });*/

        onStartCount = 1
        if (savedInstanceState == null) {
            this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left)
        } else {
            onStartCount = 2
        }

        setContentView(R.layout.simple_list)
        inicializarComponentes()
    }

    private fun inicializarComponentes() {
        app = application as MainApplication
        listaVerificacionService = app!!.listaVerificacionService
        usuarioService = app!!.usuarioService
        setSupportActionBar(app_bar as Toolbar)

        val actionBar = supportActionBar
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
            actionBar.title = "Sedes"
            actionBar.setHomeButtonEnabled(true)
        }
        rv_list.setHasFixedSize(true)
        rv_list.layoutManager = LinearLayoutManager(this)
        val menuList = ArrayList<UnidadBean>()
        cardViewAdapter = ListaUnidadesAdapter(menuList, View.OnClickListener { view -> onItemClickMenu(view) }, applicationContext)
        rv_list.adapter = cardViewAdapter

        if (isOnline) {
            descargarUnidades()
            //            descargarListaUnidad(app.getUsuarioEnSesion().getUser_login(), app.getUsuarioEnSesion().getPassword(), app.getUsuarioEnSesion().getUsuario(), app.getUsuarioEnSesion().getSc_user_id()+"", app.getUsuarioEnSesion().getIpOrDominioServidor());
        } else {
            cargarListaUnidad()
        }
    }

    fun setupTheme() {
        setTheme(R.style.MyMaterialTheme)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        app!!.usuarioEnSesion
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.action_search) {

        } else if (id == android.R.id.home) {
            onBackPressed()
            this.overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right)
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    fun onItemClickMenu(item: View) {
        val unidadBean = (item.tag as ListaUnidadesAdapter.ViewHolder).unidadBean
        when (item.id) {
            R.id.lnlyCarViewUnidad -> {
                val usuarioBean = app!!.usuarioEnSesion
                usuarioBean!!.fb_uea_pe_id = unidadBean.fb_uea_pe_id
                usuarioBean!!.fb_uea_pe_abr = unidadBean.codigo
                val isUpdate = usuarioService!!.update(usuarioBean)
                if (isUpdate == 1) {
                    app!!.usuarioEnSesion = usuarioBean
                    val i = Intent(this@ListaUnidadesActivity, MenuActivity::class.java)
                    startActivity(i)
                } else {
                    app!!.usuarioEnSesion = null
                    val i = Intent(this@ListaUnidadesActivity, MenuActivity::class.java)
                    startActivity(i)
                }
            }
        }
    }

    fun cargarListaUnidad() {
        val unidades = listaVerificacionService!!.unidadBeanList

        if (null != unidades) {
            cardViewAdapter!!.setList(unidades)
            cardViewAdapter!!.notifyDataSetChanged()
        } else {
            mostrarMensaje("No existen unidades para mostrar...!")
        }
    }

    fun mostrarMensaje(mensaje: String) {
        val toast = Toast.makeText(applicationContext, mensaje, Toast.LENGTH_SHORT)
        toast.show()
    }

    private fun descargarUnidades() {
        val dialog = ProgressDialog(this@ListaUnidadesActivity)
        val unidadLista = ArrayList<UnidadBean>()

        dialog.setMessage("Cargando unidades...")
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.show()

        val usuario = app!!.usuarioEnSesion

        val URL_EXT = usuario!!.ipOrDominioServidor
        val headers = HashMap<String, String>()
        headers["userLogin"] = usuario!!.user_login
        headers["userPassword"] = usuario!!.password
        headers["systemRoot"] = "safe2biz"
        val parameters = HashMap<String, String>()

        parameters["sc_user_id"] = usuario!!.sc_user_id!!.toString()

        AndroidNetworking.post("$URL_EXT/ws/null/pr_ws_fb_uea")
                .addHeaders(headers)
                .addBodyParameter(parameters)
                .setTag("unidades")
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(object : JSONObjectRequestListener {
                    override fun onResponse(response: JSONObject) {
                        Log.d("respo", "si")

                        try {
                            dialog.dismiss()
                            val unidad = UnidadBean()
                            val data = response.getJSONArray("data")
                            for (i in 0 until data.length()) {
                                val `object` = data.getJSONObject(i)
                                unidad.fb_uea_pe_id = `object`.getLong("fb_uea_pe_id")
                                unidad.codigo = `object`.getString("codigo")
                                unidad.nombre = `object`.getString("nombre")
                                unidad.scUserId = `object`.getLong("sc_user_id")
                                unidadLista.add(unidad)
                            }
                            Log.d("unidad", unidadLista.toString())
                            if (0 != unidadLista.size) {
                                val unidades = listaVerificacionService!!.unidadBeanList
                                if (null != unidades) {
                                    val isClearUnidades = listaVerificacionService!!.borrarUnidades()
                                    if (-1 != isClearUnidades) {
                                        listaVerificacionService!!.guardarListaUnidades(unidadLista)
                                        cargarListaUnidad()
                                    } else {
                                        mostrarMensaje("Error al guardar las unidades...!")
                                    }
                                } else {
                                    listaVerificacionService!!.guardarListaUnidades(unidadLista)
                                    cargarListaUnidad()
                                }

                            } else {
                                app!!.usuarioEnSesion = null
                                mostrarMensaje("No existen unidades para mostrar...!")
                            }
                        } catch (e: JSONException) {
                            Log.e("error", e.toString())
                            e.printStackTrace()
                        }

                    }

                    override fun onError(error: ANError) {
                        dialog.dismiss()
                    }
                })
    }
}
