package pe.dominiotech.movil.safe2biz.exception;

public class LoginException extends AppException{
	private static final long serialVersionUID = 1L;

	public LoginException(String code) {
		super(code);
	}
}

