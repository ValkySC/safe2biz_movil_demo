package pe.dominiotech.movil.safe2biz.version;

import pe.dominiotech.movil.safe2biz.service.AppService;

public class VersionService extends AppService{


}
